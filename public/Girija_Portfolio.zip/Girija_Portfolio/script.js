/**
 * ==========================================================================
 * Girija S - Personal Portfolio Website
 * Project: Girija_Portfolio
 * Technologies: Pure Vanilla JavaScript (ES6+)
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // --------------------------------------------------------------------------
  // 1. DATA CONFIGURATIONS (Easily Editable)
  // --------------------------------------------------------------------------

  // Personal & Profile Data
  const PERSONAL_INFO = {
    fullName: "Girija S",
    title: "Computer Science & AI Student",
    degree: "B.Sc. Computer Science with Artificial Intelligence",
    college: "PERI College of Arts and Science",
    studyPeriod: "2025 - 2028",
    status: "Undergraduate Student",
    location: "No:7, Andal Nagar, Ullavur, Kanchipuram district - 631606",
    email: "girijasabari5907@gmail.com",
    githubUrl: "https://github.com/Girija5907",
    linkedinUrl: "https://www.linkedin.com/in/girija-s-a9a02a368"
  };

  // Projects Data
  const PROJECTS_DATA = [
    {
      id: "gifttrack",
      name: "GiftTrack",
      subtitle: "Event & Function Gift Management",
      description: "Tracking gifts of family functions (Only-Frontend). An intuitive web application designed to track, organize, and search gifts received across family weddings, housewarmings, and special celebrations.",
      technologies: {
        frontend: ["React 19", "TypeScript", "Tailwind CSS v4", "Lucide Icons", "Motion", "Vite"],
        architecture: ["LocalStorage Persistence", "WhatsApp & Web Share APIs", "Node.js & Express runtime"]
      },
      githubUrl: "https://github.com/Girija5907/GiftTrack",
      demoUrl: "",
      accentColor: "from-indigo-600 to-blue-500",
      keyHighlights: [
        "Instant gift cataloging with donor contact tags and category filtering",
        "Client-side persistence using browser LocalStorage for offline reliability",
        "Direct integration with WhatsApp and Web Share API for thank-you messages"
      ]
    },
    {
      id: "cinebook",
      name: "CineBook",
      subtitle: "Movie Ticket Reservation Platform",
      description: "Online movie ticket booking application (Only-Frontend). Features an interactive cinema experience with dynamic showtime selection, visual seat grid picker, pricing calculation, and ticket confirmation.",
      technologies: {
        frontend: ["React 19", "TypeScript", "Tailwind CSS v4", "Motion", "Lucide React icons"],
        architecture: ["Vite 8", "esbuild 0.28", "Express", "Vercel Cloud Hosting"]
      },
      githubUrl: "https://github.com/Girija5907/CineBook",
      demoUrl: "",
      accentColor: "from-sky-500 to-indigo-600",
      keyHighlights: [
        "Awarded 2nd Prize in UI/UX Design at INNOVARA'26 Symposium",
        "Interactive theatre seating matrix with real-time seat availability logic",
        "Dynamic cart calculator with popcorn add-ons, convenience fee, and ticket preview"
      ]
    }
  ];

  // Achievements Data with "Visit Certificate" links
  const ACHIEVEMENTS_DATA = [
    {
      id: "ach-1",
      prize: "First Prize",
      prizeType: "first",
      title: "First Prize — Debugging Event",
      event: "InterCollegiate Symposium, DEVXPLORES-2K26",
      organization: "Mohamed Sathak College of Arts and Science",
      date: "March 11, 2026",
      description: "Successfully identified, analyzed, and debugged complex Python codes under strict competitive time limits, demonstrating sharp algorithmic logic and syntax proficiency.",
      certificateUrl: "certificates/debugging-first-prize.html"
    },
    {
      id: "ach-2",
      prize: "Second Prize",
      prizeType: "second",
      title: "Second Prize — UI/UX Design",
      event: "InterCollegiate Symposium, INNOVARA'26",
      organization: "Prince Shri Balaji Arts and Science College",
      date: "September 19, 2026",
      description: "Designed and built an intuitive, modern online movie ticket booking application called \"CineBook\" featuring a visual seating layout, accessible contrast, and smooth booking flow.",
      certificateUrl: "certificates/uiux-second-prize.html"
    },
    {
      id: "ach-3",
      prize: "Second Prize",
      prizeType: "second",
      title: "Second Prize — Poster Parade Competition",
      event: "IntraCollegiate Symposium, PERI COGNIZANCE 2K25",
      organization: "PERI College of Arts and Science",
      date: "September 19, 2025",
      description: "Created an awareness poster on 'SAY NO TO DRUGS' using graphic design principles in Canva and presented an articulate verbal campaign on substance abuse prevention.",
      certificateUrl: "certificates/poster-parade-second-prize.html"
    }
  ];

  // Certifications Data with "Visit Certificate" links
  const CERTIFICATES_DATA = [
    {
      id: "cert-1",
      name: "Google Slides",
      issuer: "Cursa E-Learning",
      completionDate: "August 4, 2026",
      duration: "56 minutes",
      certificateId: "c294b10b03e42387f5da938b2020775",
      certificateUrl: "https://cursa.app/en/my-certificate/certc294b10b0b3e423f87d5a938b2020775",
      description: "Completed the Google Slides for Beginners course on the Cursa e-learning platform on August 4, 2026. Learned the fundamentals of Google Slides, master templates, and creating professional visual presentations."
    },
    {
      id: "cert-2",
      name: "Typewriting — Junior (English)",
      issuer: "Board of Examinations, Tamil Nadu",
      completionDate: "February 2024",
      level: "Junior",
      language: "English",
      result: "First Class",
      certificateId: "1540421",
      certificateUrl: "certificates/typewriting-junior.html",
      description: "Government recognized technical qualification in English Typewriting at Junior Grade with First Class distinction from the Department of Technical Education, Tamil Nadu."
    },
    {
      id: "cert-3",
      name: "Typewriting — Senior (English)",
      issuer: "Board of Examinations, Tamil Nadu",
      completionDate: "August 2024",
      level: "Senior",
      language: "English",
      result: "First Class",
      certificateId: "1590983",
      certificateUrl: "certificates/typewriting-senior.html",
      description: "Advanced government recognized qualification in English Typewriting at Senior Grade with First Class distinction, demonstrating high typing speed, accuracy, and official correspondence layout mastery."
    }
  ];

  // --------------------------------------------------------------------------
  // 2. THEME CONTROLLER (Dark / Light Theme with localStorage)
  // --------------------------------------------------------------------------
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const savedTheme = localStorage.getItem('girija_portfolio_theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const currentTheme = savedTheme || (systemPrefersDark ? 'dark' : 'dark');
  document.documentElement.setAttribute('data-theme', currentTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const activeTheme = document.documentElement.getAttribute('data-theme');
      const nextTheme = activeTheme === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', nextTheme);
      localStorage.setItem('girija_portfolio_theme', nextTheme);
    });
  }

  // --------------------------------------------------------------------------
  // 3. MOBILE NAVIGATION (Hamburger Menu Toggle & Auto-Close)
  // --------------------------------------------------------------------------
  const mobileToggleBtn = document.getElementById('mobileNavToggle');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (mobileToggleBtn && navMenu) {
    mobileToggleBtn.addEventListener('click', () => {
      const isOpen = navMenu.classList.contains('open');
      if (isOpen) {
        navMenu.classList.remove('open');
        mobileToggleBtn.setAttribute('aria-expanded', 'false');
      } else {
        navMenu.classList.add('open');
        mobileToggleBtn.setAttribute('aria-expanded', 'true');
      }
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          mobileToggleBtn.setAttribute('aria-expanded', 'false');
        }
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && navMenu.classList.contains('open')) {
        navMenu.classList.remove('open');
        mobileToggleBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --------------------------------------------------------------------------
  // 4. ACTIVE NAVIGATION LINK ON SCROLL (IntersectionObserver)
  // --------------------------------------------------------------------------
  const sectionIds = ['home', 'about', 'skills', 'education', 'projects', 'achievements', 'certifications', 'contact'];
  const sections = sectionIds.map(id => document.getElementById(id)).filter(Boolean);

  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -70% 0px',
    threshold: 0
  };

  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(sec => navObserver.observe(sec));

  // --------------------------------------------------------------------------
  // 5. RENDER PROJECTS (Dynamic & Editable)
  // --------------------------------------------------------------------------
  const projectsGrid = document.getElementById('projectsGrid');
  if (projectsGrid) {
    projectsGrid.innerHTML = PROJECTS_DATA.map((proj, idx) => `
      <article class="project-card" data-project-id="${proj.id}">
        <div class="project-preview">
          <div class="project-preview-mock">
            <div class="mock-window-bar">
              <span class="mock-dot red"></span>
              <span class="mock-dot yellow"></span>
              <span class="mock-dot green"></span>
            </div>
            <div class="mock-body">
              <div class="mock-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                  <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
                </svg>
                <span>${proj.name} Preview</span>
              </div>
              <div class="mock-line w-80"></div>
              <div class="mock-line w-60"></div>
            </div>
          </div>
        </div>

        <div class="project-content">
          <span class="project-meta-kicker">Project 0${idx + 1} · Frontend Application</span>
          <h3 class="project-title">${proj.name}</h3>
          <p class="project-desc">${proj.description}</p>

          <div class="project-tech-block">
            <span class="tech-group-title">Frontend & UI Technologies</span>
            <div class="tech-tags">
              ${proj.technologies.frontend.map(t => `<span class="tech-tag">${t}</span>`).join('')}
            </div>

            <span class="tech-group-title">Architecture & Tooling</span>
            <div class="tech-tags">
              ${proj.technologies.architecture.map(t => `<span class="tech-tag">${t}</span>`).join('')}
            </div>
          </div>

          <div class="project-actions">
            <a href="${proj.githubUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" aria-label="View ${proj.name} source code on GitHub">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path>
                <path d="M9 18c-4.51 2-5-2-7-2"></path>
              </svg>
              GitHub Repository
            </a>
            <button type="button" class="btn btn-outline btn-sm view-project-btn" data-proj-id="${proj.id}">
              Details
            </button>
          </div>
        </div>
      </article>
    `).join('');
  }

  // --------------------------------------------------------------------------
  // 6. RENDER ACHIEVEMENTS with "Visit Certificate" button
  // --------------------------------------------------------------------------
  const achievementsGrid = document.getElementById('achievementsGrid');
  if (achievementsGrid) {
    achievementsGrid.innerHTML = ACHIEVEMENTS_DATA.map((ach) => `
      <article class="achievement-card">
        <span class="prize-badge ${ach.prizeType}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="6"></circle>
            <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"></path>
          </svg>
          ${ach.prize}
        </span>

        <h3 class="achievement-title">${ach.title}</h3>
        <p class="achievement-event">${ach.event}</p>
        <p class="achievement-org">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path>
            <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path>
            <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path>
            <path d="M10 6h4"></path>
            <path d="M10 10h4"></path>
            <path d="M10 14h4"></path>
            <path d="M10 18h4"></path>
          </svg>
          ${ach.organization}
        </p>
        <p class="achievement-date">Date: ${ach.date}</p>
        <p class="achievement-desc">${ach.description}</p>

        <div class="achievement-action">
          <a href="${ach.certificateUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" aria-label="Visit certificate for ${ach.title}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
            Visit Certificate
          </a>
        </div>
      </article>
    `).join('');
  }

  // --------------------------------------------------------------------------
  // 7. RENDER CERTIFICATIONS with "Visit Certificate" button
  // --------------------------------------------------------------------------
  const certsGrid = document.getElementById('certificationsGrid');
  if (certsGrid) {
    certsGrid.innerHTML = CERTIFICATES_DATA.map((cert) => `
      <article class="cert-card">
        <div class="cert-icon-row">
          <div class="cert-icon-wrapper">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
              <circle cx="12" cy="14" r="3"></circle>
              <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
            </svg>
          </div>
          <span class="cert-status-tag">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            Verified
          </span>
        </div>

        <h3 class="cert-name">${cert.name}</h3>
        <p class="cert-issuer">${cert.issuer}</p>

        <div class="cert-meta-list">
          <div class="cert-meta-row">
            <span class="cert-meta-label">Completion Date:</span>
            <span class="cert-meta-val">${cert.completionDate}</span>
          </div>
          ${cert.duration ? `
            <div class="cert-meta-row">
              <span class="cert-meta-label">Course Duration:</span>
              <span class="cert-meta-val">${cert.duration}</span>
            </div>
          ` : ''}
          ${cert.level ? `
            <div class="cert-meta-row">
              <span class="cert-meta-label">Examination Grade:</span>
              <span class="cert-meta-val">${cert.level} (${cert.result || 'First Class'})</span>
            </div>
          ` : ''}
        </div>

        ${cert.certificateId ? `
          <div class="cert-id-block">
            <strong>ID:</strong> ${cert.certificateId}
          </div>
        ` : ''}

        <p class="cert-desc">${cert.description}</p>

        <div class="cert-actions">
          <a href="${cert.certificateUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" aria-label="Visit ${cert.name} certificate">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
            Visit Certificate
          </a>
        </div>
      </article>
    `).join('');
  }

  // --------------------------------------------------------------------------
  // 8. PROJECT DETAILS MODAL
  // --------------------------------------------------------------------------
  const modalOverlay = document.getElementById('projectModal');
  const modalContent = document.getElementById('modalContent');
  const modalCloseBtn = document.getElementById('modalCloseBtn');

  const openProjectModal = (projId) => {
    const project = PROJECTS_DATA.find(p => p.id === projId);
    if (!project || !modalContent) return;

    modalContent.innerHTML = `
      <h2 style="font-size: 1.5rem; font-weight: 800; color: var(--text-primary); margin-bottom: 8px;">${project.name}</h2>
      <p style="font-size: 0.875rem; color: var(--accent-blue); font-weight: 600; margin-bottom: 16px;">${project.subtitle}</p>
      
      <p style="font-size: 0.9375rem; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
        ${project.description}
      </p>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 0.8125rem; font-weight: 700; text-transform: uppercase; color: var(--accent-violet); margin-bottom: 8px;">Key Implementation Highlights</h4>
        <ul style="list-style: disc; padding-left: 20px; font-size: 0.875rem; color: var(--text-secondary); display: flex; flex-direction: column; gap: 6px;">
          ${project.keyHighlights.map(h => `<li>${h}</li>`).join('')}
        </ul>
      </div>

      <div style="margin-bottom: 24px;">
        <h4 style="font-size: 0.8125rem; font-weight: 700; text-transform: uppercase; color: var(--accent-violet); margin-bottom: 8px;">Stack & Tooling</h4>
        <div style="display: flex; flex-wrap: wrap; gap: 6px;">
          ${[...project.technologies.frontend, ...project.technologies.architecture].map(t => `<span class="tech-tag">${t}</span>`).join('')}
        </div>
      </div>

      <div style="display: flex; gap: 12px; border-top: 1px solid var(--border-subtle); padding-top: 20px;">
        <a href="${project.githubUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">
          Visit GitHub Repository
        </a>
        <button type="button" class="btn btn-secondary btn-sm close-modal-trigger">
          Close
        </button>
      </div>
    `;

    modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';

    const innerClose = modalContent.querySelector('.close-modal-trigger');
    if (innerClose) {
      innerClose.addEventListener('click', closeModal);
    }
  };

  const closeModal = () => {
    if (!modalOverlay) return;
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  };

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.view-project-btn');
    if (btn) {
      const projId = btn.getAttribute('data-proj-id');
      openProjectModal(projId);
    }
  });

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', closeModal);
  }

  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalOverlay && modalOverlay.classList.contains('active')) {
      closeModal();
    }
  });

  // --------------------------------------------------------------------------
  // 9. BACK TO TOP BUTTON
  // --------------------------------------------------------------------------
  const backToTopBtn = document.getElementById('backToTopBtn');
  if (backToTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    });

    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // --------------------------------------------------------------------------
  // 10. DYNAMIC CURRENT YEAR
  // --------------------------------------------------------------------------
  const yearElement = document.getElementById('currentYear');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
});
