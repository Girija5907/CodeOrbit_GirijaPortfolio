# Certificates Directory (`certificates/`)

Place digital copies (PDF, JPG, or PNG) of your symposium awards and course certificates in this directory.

### Suggested File Naming:

- `google-slides-cursa.pdf` or `google-slides-cursa.png`
- `typewriting-junior-tamilnadu.pdf`
- `typewriting-senior-tamilnadu.pdf`
- `debugging-first-prize-devxplores.pdf`
- `uiux-second-prize-innovara.pdf`
- `poster-second-prize-peri-cognizance.pdf`

### How to link a certificate in `script.js`:
In `script.js`, locate the certificate or achievement entry and set its `certificateUrl` field:
```javascript
certificateUrl: "certificates/typewriting-junior-tamilnadu.pdf"
```
When this field contains a valid file path or web link, the **View File** or **View Certificate** button will automatically appear on the corresponding card on the website!
